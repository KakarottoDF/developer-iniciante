public interface Validador {
    boolean moradorExiste(String nome);
    boolean revistaExiste(String nome);
}
