public enum Regiao {
    QNA,
    CNB
}
